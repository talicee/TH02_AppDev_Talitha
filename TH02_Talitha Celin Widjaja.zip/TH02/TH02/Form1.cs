﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class Form1 : Form
    {
        public static string word1;
        public static string word2;
        public static string word3;
        public static string word4;
        public static string word5;
        public Form1()
        {
            InitializeComponent();
        }
        //INPUT HURUF BESAR
        private void btn_play_Click(object sender, EventArgs e)
        {
            word1 = tb_word1.Text.ToUpper();
            word2 = tb_word2.Text.ToUpper(); 
            word3 = tb_word3.Text.ToUpper(); 
            word4 = tb_word4.Text.ToUpper(); 
            word5 = tb_word5.Text.ToUpper(); 

            if (tb_word1.Text.Length != 5 || tb_word2.Text.Length != 5 || tb_word3.Text.Length != 5 || tb_word4.Text.Length != 5 || tb_word5.Text.Length != 5)
            {
                MessageBox.Show("Error. Must be 5 letters");
            }

            else if (tb_word1.Text == tb_word2.Text
                || tb_word1.Text == tb_word3.Text
                || tb_word1.Text == tb_word4.Text
                || tb_word1.Text == tb_word5.Text
                || tb_word3.Text == tb_word2.Text
                || tb_word4.Text == tb_word2.Text
                || tb_word5.Text == tb_word2.Text
                || tb_word3.Text == tb_word4.Text
                || tb_word3.Text == tb_word5.Text
                || tb_word4.Text == tb_word5.Text)
            {
                MessageBox.Show("Error. There are same words");
            }
            else
            {
                MessageBox.Show("Let's PLAY !!");
                Form2 game = new Form2();
                game.Show();
                this.Hide();
            }
        }
    }
}
