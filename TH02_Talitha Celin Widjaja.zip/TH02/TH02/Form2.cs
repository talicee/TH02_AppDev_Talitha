﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH02
{
    public partial class Form2 : Form
    {
        
        Random rnd = new Random();
        List<string> listKata = new List<string>() {Form1.word1, Form1.word2, Form1.word3, Form1.word4, Form1.word5};
        List<char> hurufSoal = new List<char>();
        List<string> garis = new List<string>();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            garis.Add(lb_huruf1.Text);
            garis.Add(lb_huruf2.Text);
            garis.Add(lb_huruf3.Text);
            garis.Add(lb_huruf4.Text);
            garis.Add(lb_huruf5.Text);

            int indexSoal = rnd.Next(0, listKata.Count);
            string soal = listKata[indexSoal];
            lb_jwban.Text = soal; //jwban soal

            foreach (char s in soal)
            {
                hurufSoal.Add(s);
            }
        }

    //HURUF BESAR
    char hurufpencet ;
        void Checkhuruf(List<char>hurufSoal, List<string>garis, string soal)
        {
            if (soal.Contains(hurufpencet))
            {
                for (int i = 0; i < 5; i++)
                {
                    if (hurufSoal[i] == hurufpencet)
                    {
                        garis[i] = Convert.ToString(hurufpencet);
                    }
                }
                lb_huruf1.Text = garis[0];
                lb_huruf2.Text = garis[1];
                lb_huruf3.Text = garis[2];
                lb_huruf4.Text = garis[3];
                lb_huruf5.Text = garis[4];
            }
            if (lb_huruf1.Text != "_" && lb_huruf2.Text != "_" && lb_huruf3.Text != "_" && lb_huruf4.Text != "_" && lb_huruf5.Text != "_")
            {
                MessageBox.Show("Yey You did it");
            }
        }

        private void btn_Q_Click(object sender, EventArgs e)
        {
            hurufpencet = 'Q';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_W_Click(object sender, EventArgs e)
        {
            hurufpencet = 'W';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_E_Click(object sender, EventArgs e)
        {
            hurufpencet = 'E';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_R_Click(object sender, EventArgs e)
        {
            hurufpencet = 'R';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_T_Click(object sender, EventArgs e)
        {
            hurufpencet = 'T';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_Y_Click(object sender, EventArgs e)
        {
            hurufpencet = 'Y';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_U_Click(object sender, EventArgs e)
        {
            hurufpencet = 'U';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_I_Click(object sender, EventArgs e)
        {
            hurufpencet = 'I';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_O_Click(object sender, EventArgs e)
        {
            hurufpencet = 'O';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_P_Click(object sender, EventArgs e)
        {
            hurufpencet = 'P';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_A_Click(object sender, EventArgs e)
        {
            hurufpencet = 'A';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_S_Click(object sender, EventArgs e)
        {
            hurufpencet = 'S';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_D_Click(object sender, EventArgs e)
        {
            hurufpencet = 'D';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_F_Click(object sender, EventArgs e)
        {
            hurufpencet = 'F';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_G_Click(object sender, EventArgs e)
        {
            hurufpencet = 'G';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_H_Click(object sender, EventArgs e)
        {
            hurufpencet = 'H';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_J_Click(object sender, EventArgs e)
        {
            hurufpencet = 'J';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_K_Click(object sender, EventArgs e)
        {
            hurufpencet = 'K';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_L_Click(object sender, EventArgs e)
        {
            hurufpencet = 'L';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_Z_Click(object sender, EventArgs e)
        {
            hurufpencet = 'Z';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_X_Click(object sender, EventArgs e)
        {
            hurufpencet = 'X';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_C_Click(object sender, EventArgs e)
        {
            hurufpencet = 'C';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_V_Click(object sender, EventArgs e)
        {
            hurufpencet = 'V';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_B_Click(object sender, EventArgs e)
        {
            hurufpencet = 'B';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_N_Click(object sender, EventArgs e)
        {
            hurufpencet = 'N';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }

        private void btn_M_Click(object sender, EventArgs e)
        {
            hurufpencet = 'M';
            Checkhuruf(hurufSoal, garis, lb_jwban.Text);
        }


        // dpt menampilkan huruf benar ditebak 15
        // dpt melakukann input tepat 15
        // menghilangkan textbox input dan menampilikan keyboard 10
        //tdk mengganti nama -5
    }
}
